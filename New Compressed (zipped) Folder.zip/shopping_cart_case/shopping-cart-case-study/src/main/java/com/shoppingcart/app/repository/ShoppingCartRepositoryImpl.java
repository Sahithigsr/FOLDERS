package com.shoppingcart.app.repository;

import com.shoppingcart.app.exception.InvalidQuantityException;
import com.shoppingcart.app.exception.ProductNotFoundException;
import com.shoppingcart.app.model.Product;

import java.util.ArrayList;
import java.util.Comparator;
import java.util.List;
import java.util.Optional;

public class ShoppingCartRepositoryImpl implements ShoppingCartRepository {

    List<Product>products=new ArrayList<>();

    public void addProduct(Product product, int quantity) throws InvalidQuantityException {
        if(quantity<=0)
        {
            throw new InvalidQuantityException("e");
        }
            product.setQuantity(quantity);
            products.add(product);

    }

    public void removeProduct(Product product) throws ProductNotFoundException {
        Optional<Product> p= products.stream().filter(i->i.getId()==product.getId()).findFirst();
        if(p.isEmpty())
            throw new ProductNotFoundException("e");
        products.remove(product);

    }

    public void updateProductQuantity(Product product, int quantity) throws ProductNotFoundException, InvalidQuantityException {

        if(quantity<0)
        {
            throw new InvalidQuantityException("e");
        }
        Optional<Product> p= products.stream().filter(i->i.getId()==product.getId()).findFirst();
        if(p.isEmpty())
            throw new ProductNotFoundException("e");
        product.setQuantity(quantity);
    }

    public double calculateTotalPrice() {
       return products.stream().mapToDouble(i->i.getPrice()*i.getQuantity()).sum();

    }

    public List<Product> filterProductsByCategory(String category) {
        return products.stream().filter(i->i.getCategory().equalsIgnoreCase(category)).toList();

    }

    public List<Product> filterProductsByPriceRange(double minPrice, double maxPrice) {
        return products.stream().filter(i->i.getPrice()>=minPrice && i.getPrice()<=maxPrice).toList();

    }



    // Output Format:
    //Product1 2 10.0
    //Product2 3 20.0
    public void displayCartItems() {

        products.forEach(i->
        {
            System.out.print(i.getName()+" "+i.getQuantity()+" "+i.getPrice()+"\n");

        });

    }

    public Optional<Product> findMostExpensiveProduct() {
        return products.stream().sorted((i,j)->(int)j.getPrice()-(int)i.getPrice()).findFirst();
    }

    public List<Product> sortProductsByName() {
        //return products.stream().sorted(Comparator.comparing(i->i.getName())).toList();
        return products.stream().sorted((i,j)->i.getName().compareTo(j.getName())).toList();

    }

    public double calculateDiscountedTotal(double discountPercentage) {
        return products.stream().mapToDouble(i->i.getPrice()*i.getQuantity()*(100-discountPercentage)/100).sum();
    }

    public List<Product> getProducts() {
        return products.stream().toList();
    }
}
