package com.stackroute.streams;

import java.io.*;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.*;
import java.util.regex.Pattern;
import java.util.stream.Collectors;
import java.util.stream.Stream;

public class FileOperationsUsingStreams {
    public int getUniqueWordCount(String str) {


        Path filePath = Paths.get(str.trim());
        if (str.trim().isEmpty()||!Files.exists(filePath)) {
            return 0;
        }

        try (BufferedReader br = new BufferedReader(new FileReader(str))) {
            return (int) br.lines()
                    .flatMap(i -> Stream.of(i.split("\\s+")))
                    .distinct()
                    .count();
        } catch (IOException e) {
            return 0;
        }
    }

    public Set<String> getWordListWithoutDuplicates(String str) {
        Path filePath = Paths.get(str.trim());
        Set<String> k=new HashSet<>();
        if (str.trim().isEmpty()||!Files.exists(filePath) || !Files.isReadable(filePath)) {
            return k;
        }
        try (BufferedReader br = new BufferedReader(new FileReader(str))){
            return br.lines()
                    .flatMap(i -> Stream.of(i.split("\\s+")))
                    .collect(Collectors.toSet());
        } catch (IOException e) {
            return k;
        }
    }

    List<String> getWordListInUppercaseExcludingFirstLine(String str) {
        List<String> k=new ArrayList<>();
        Path filePath = Paths.get(str.trim());
        if (str.trim().isEmpty()||!Files.exists(filePath) || !Files.isReadable(filePath)) {
            return k;
        }

        try {
            BufferedReader br = new BufferedReader(new FileReader(str));
            //br.readLine();
            return br.lines()
                    .skip(1)
                    .flatMap(i -> Stream.of(i.split("\\s+")))
                    .map(i->i.toUpperCase())
                    .toList();
        } catch (Exception e) {
            return k;
        }
    }

    String getEachWordsSeparatedByColon(String str) {
        Path filePath = Paths.get(str.trim());
        if ( str.trim().isEmpty() || !Files.exists(filePath) || !Files.isReadable(filePath)) {
            return null;
        }
        try {
            BufferedReader br = new BufferedReader(new FileReader(str));
            return br.lines()
                    .flatMap(i -> Stream.of(i.split("\\s+")))
                    .collect(Collectors.joining(":"));
        } catch (  FileNotFoundException e) {
            return null;
        }
    }

    String getEachLineSeparatedByComma(String str) {
        Path path = Paths.get(str.trim());
        if(str.trim().isEmpty()||!Files.exists(path)||!Files.isReadable(path)){
            return null;
        }
        try {
            BufferedReader br = new BufferedReader(new FileReader(str));
            return br.lines().collect(Collectors.joining(","));
        } catch (FileNotFoundException e) {
            return null;
        }
    }






    public Optional<Integer> getSumOfIntegers(String str) {
        Path filePath = Paths.get(str.trim());
        if (str.trim().isEmpty()||!Files.exists(filePath) || !Files.isReadable(filePath)) {
            return Optional.empty();
        }

        try (BufferedReader br = Files.newBufferedReader(filePath)){
            return  br.lines()
                    .flatMap(i->Stream.of(i.split("\\s+")))
                    .filter(i -> i.matches("-?\\d+"))
                    .map(i-> Integer.parseInt(i))
                    .reduce(Integer::sum);
        } catch (IOException e) {
            return Optional.empty();
        }
    }



    public Optional<Integer> getMaxOfIntegers(String str) {
        Path filePath = Paths.get(str.trim());
        if (str.trim().isEmpty()||!Files.exists(filePath) || !Files.isReadable(filePath)) {
            return Optional.empty();
        }
        try (BufferedReader br = Files.newBufferedReader(filePath)) {
            return br.lines()
                    .flatMap(i -> Stream.of(i.split("\\s+")))//all words
                    .filter(k -> k.matches("\\d+"))
                    .map(Integer::parseInt)
                    .max((i,j)->i.compareTo(j));
        } catch (IOException e) {
            return Optional.empty();
        }
    }

}

