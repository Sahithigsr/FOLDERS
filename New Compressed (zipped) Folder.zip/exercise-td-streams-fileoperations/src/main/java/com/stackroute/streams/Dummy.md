**This file is created to maintain the maven structure in Gitlab and can be deleted!**
public class FileOperationsUsingStreams
{

public void getUniqueWordCount
{


