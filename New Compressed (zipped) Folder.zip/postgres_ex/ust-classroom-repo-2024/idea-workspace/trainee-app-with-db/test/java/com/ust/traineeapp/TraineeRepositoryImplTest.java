package com.ust.traineeapp;

import com.ust.traineeapp.repository.TraineeRepositoryImpl;
import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

import java.util.Optional;

import static com.sun.org.apache.xerces.internal.util.PropertyState.is;

public class TraineeRepositoryImplTest {
    private TraineeRepositoryImpl t;

    @BeforeEach
    void setup() {
        t=new TraineeRepositoryImpl();
    }

    @AfterEach
    void tearDown()
    {
        t=null;
    }

    @Test
    void saveTest()
    {
        Assertions.assertEquals(.);
    }

    @Test
    void getAllTraineesTest()
    {
        assertThat(t.getAllTrainees(),is(Optional.of));
        //assertThat(MSG_01, batsmanService.getBatsman(batsmanList, "virat", "IN"), is(Optional.of(batsmanVirat)))
    }



}
