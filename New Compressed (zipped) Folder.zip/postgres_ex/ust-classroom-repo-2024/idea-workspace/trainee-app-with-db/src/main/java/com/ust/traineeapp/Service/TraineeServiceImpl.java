package com.ust.traineeapp.Service;

import com.ust.traineeapp.model.Trainee;
import com.ust.traineeapp.repository.TraineeRepository;
import com.ust.traineeapp.repository.TraineeRepositoryImpl;

import java.util.List;

public class TraineeServiceImpl implements TraineeService{

private TraineeRepository traineeRepository=new TraineeRepositoryImpl();

    @Override
    public Trainee saveTrainee(Trainee trainee) {
        return traineeRepository.save(trainee);

    }

    @Override
    public Trainee getTraineebyId(int id) {
        return traineeRepository.getTrainee(id);
    }

    @Override
    public List<Trainee> getEveryTrainees() {
        return traineeRepository.getAllTrainees();
    }



    @Override
    public void deleteTrainee(int id) {
        traineeRepository.deleteTrainee(id);
    }
}
