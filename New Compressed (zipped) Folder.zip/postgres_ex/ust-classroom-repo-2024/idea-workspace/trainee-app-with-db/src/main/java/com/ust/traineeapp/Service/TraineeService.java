package com.ust.traineeapp.Service;

import com.ust.traineeapp.model.Trainee;

import java.util.List;
import java.util.Optional;

public interface TraineeService {

    public Trainee saveTrainee(Trainee trainee);

    public Trainee getTraineebyId(int id);

    public List<Trainee> getEveryTrainees();

    public void deleteTrainee(int id);

}
