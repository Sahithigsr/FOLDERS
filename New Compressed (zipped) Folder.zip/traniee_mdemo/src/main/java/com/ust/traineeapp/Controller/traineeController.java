package com.ust.traineeapp.Controller;
import com.ust.traineeapp.model.Trainee;
import com.ust.traineeapp.repository.TraineeRepository;
import com.ust.traineeapp.repository.TraineeRepositoryImpl;
import jakarta.servlet.RequestDispatcher;
import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.io.PrintWriter;
import java.time.LocalDate;
import java.util.List;

@WebServlet("/trainees/*")

public class traineeController extends HttpServlet {

    TraineeRepository traineeRepository;

    @Override
    public void init() throws ServletException {
        traineeRepository= new TraineeRepositoryImpl();
    }

    private void addTrainee(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        int id = Integer.parseInt(req.getParameter("id"));
        String name = req.getParameter("name");
        String location = req.getParameter("location");
        LocalDate date = LocalDate.parse(req.getParameter("date"));

        Trainee trainee = new Trainee(id, name, location, date);
        traineeRepository.save(trainee);
        List<Trainee> trainees = traineeRepository.getAllTrainees();
        req.setAttribute("trainees", trainees);
        RequestDispatcher requestDispatcher = req.getRequestDispatcher("/view.jsp");

        requestDispatcher.forward(req,resp);

    }

    private void getTrainee(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        RequestDispatcher requestDispatcher = req.getRequestDispatcher("/view.jsp");
        List<Trainee> trainees = traineeRepository.getAllTrainees();
        req.setAttribute("trainees", trainees);

        requestDispatcher.forward(req, resp);

    }

    private void deleteTrainee(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        int id=Integer.parseInt(req.getParameter("id"));
        traineeRepository.deleteTrainee(id);
        RequestDispatcher requestDispatcher = req.getRequestDispatcher("/view.jsp");
        List<Trainee> trainees = traineeRepository.getAllTrainees();
        req.setAttribute("trainees", trainees);

        requestDispatcher.forward(req, resp);

    }



    public void service(HttpServletRequest req, HttpServletResponse resp) throws IOException, ServletException {

//        int id = Integer.parseInt(req.getParameter("id"));
//        String name = req.getParameter("name");
//        String location = req.getParameter("location");
//        LocalDate date = LocalDate.parse(req.getParameter("date"));
//
//        Trainee trainee=new Trainee(id,name,location,date);
//        System.out.println(trainee);
//
//        req.setAttribute("trainee",trainee);
//        RequestDispatcher requestDispatcher=req.getRequestDispatcher("/view.jsp");
//        requestDispatcher.forward(req,resp);

        String path = req.getRequestURI();
        System.out.println(path);
        if(path.contains("/add")) {
            addTrainee(req, resp);
        }
        else if (path.contains("/get")) {
            getTrainee(req, resp);
        }
        else if(path.contains("/delete"))
        {
            deleteTrainee(req,resp);
        }


//        PrintWriter out= resp.getWriter();
//
//        out.println("hello "+name);


               }}