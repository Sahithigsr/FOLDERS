package com.ust.traineeapp.repository;

import com.ust.traineeapp.model.Trainee;
import com.ust.traineeapp.util.JdbcConnectionUtil;

import java.sql.*;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.List;

public class TraineeRepositoryImpl implements TraineeRepository{

    List<Trainee> trainees = new ArrayList<>();


    public Trainee save(Trainee trainee) {

        Connection connection = JdbcConnectionUtil.createConnction();
        String sql = "insert into trainee(name,location,date_joined) values(?,?,?)";

        try {
            PreparedStatement statement = connection.prepareStatement(sql);
            statement.setString(1,trainee.name());
            statement.setString(2,trainee.location());
            statement.setDate(3,Date.valueOf(trainee.joinedDate()));
            int rowCount = statement.executeUpdate();
            System.out.println(rowCount+" rows inserted");
        } catch (SQLException e) {
            throw new RuntimeException(e);
        }


        return trainee;

//        trainees.add(trainee);
//        return trainee;

    }

    public Trainee getTrainee(int id) {

       // return trainees.stream().filter(trainee -> trainee.getId() == id).findFirst().orElse(null);
        Connection connection = JdbcConnectionUtil.createConnction();
        String sql="select * from trainee where id=?";
//        Trainee trainee = new Trainee(null);
        try
        {
            Statement statement = connection.createStatement();
            ResultSet resultSet = statement.executeQuery(sql);
            Trainee trainee = null;
            while (resultSet.next()){
                int id1 = resultSet.getInt("id");
                String name = resultSet.getString("name");
                String location = resultSet.getString("location");
                LocalDate joinedDate = resultSet.getDate("date_joined").toLocalDate();
                trainee = new Trainee(id1,name,location,joinedDate);

            }
            return trainee;

        } catch (SQLException e) {
            throw new RuntimeException(e);
        }
//        return trainee;


    }

    public List<Trainee> getAllTrainees() {

        Connection connection = JdbcConnectionUtil.createConnction();

        String sql = "select * from trainee";

        try {
            Statement statement = connection.createStatement();
            ResultSet resultSet = statement.executeQuery(sql);
            List<Trainee> trainees = new ArrayList<>();
            while (resultSet.next()){
                int id = resultSet.getInt("id");
                String name = resultSet.getString("name");
                String location = resultSet.getString("location");
                LocalDate joinedDate = resultSet.getDate("date_joined").toLocalDate();
                Trainee trainee = new Trainee(id,name,location,joinedDate);
                trainees.add(trainee);
            }
            return trainees;
        } catch (SQLException e) {
            throw new RuntimeException(e);
        }
       // return trainees;
    }

    public void deleteTrainee(int id) {

//        Connection connection = JdbcConnectionUtil.createConnction();
//
//        String sql = "select * from trainee";
//        Trainee a=trainees.stream().filter(trainee -> trainee.getId() == id).findFirst().get();
//        trainees.remove(a);

        Connection connection = JdbcConnectionUtil.createConnction();
        String sql ="delete from trainee where id=?";
        try{
            Statement statement = connection.createStatement();

            int a = statement.executeUpdate(sql);
            System.out.println("deleted "+a);
        }catch (SQLException ex){            throw new RuntimeException(ex);}


    }
}
