
<%@ page import="com.ust.traineeapp.model.Trainee" isELIgnored="false"%>
<%@ page import="java.util.List" %>
<!DOCTYPE html>
<html>
<head>
    <title>View</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-QWTKZyjpPEjISv5WaRU9OFeRpok6YctnYmDr5pNlyT2bRjXh0JMhjY6hW+ALEwIH" crossorigin="anonymous">

    </head>
    <body>
    <div class="container">
    <jsp:include page="header.jsp" />
     <%
       List<Trainee> trainees = (List<Trainee>) request.getAttribute("trainees");

    out.println("<table class='table table-striped'><tr><th>ID</th><th>Name</th><th>Location</th><th>Joined Date</th><th></th></tr>");
            for(Trainee i : trainees){
                out.print("<tr><td>" + i.getId() + "</td><td>" + i.getName() + "</td><td>" + i.getLocation() + "</td><td>" + i.getJoinedDate() + "</td>"+ "<td><button class='btn btn-danger' type='button' onclick='confirmDelete(" + i.getId() + ")'>Delete</button></td></tr>");

            }
            out.println("</table>");
            %>


            <script>
                function confirmDelete(id) {
                    if (confirm("Are you sure you want to delete this record?")) {
                        window.location.href = "deleteTrainee?id=" + id;
                    }
                }
            </script>





     </div>

    </body>

  </html>