package nio;

import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Paths;

public class ReadingFile {
    public static void main(String[] args) throws IOException {
        Files.lines(Paths.get("data.txt"))
                .forEach(System.out::println);

    }


}
