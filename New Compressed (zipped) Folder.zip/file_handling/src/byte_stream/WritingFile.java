package byte_stream;

import javax.imageio.stream.FileImageOutputStream;
import java.io.*;
import java.util.Scanner;

public class WritingFile {
    public static void main(String[] args) {
        OutputStream output = null;
        try
        {
             output=new FileOutputStream("output.txt");
             String lines= """
                     im writing on these file with bs
                     """;
             output.write(lines.getBytes());



        }
        catch(IOException ex)
        {
            System.err.println(ex);
        }
        finally
        {
            try {
                output.close();
            } catch (IOException e) {
                throw new RuntimeException(e);
            }
        }
    }
}
