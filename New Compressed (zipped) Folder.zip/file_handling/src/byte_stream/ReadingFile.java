package byte_stream;

import java.io.*;
import java.util.Scanner;

public class ReadingFile {
    public static void main(String[] args) {
        try
        {
            InputStream input=new FileInputStream("data.txt");
//            int ch;
//            while((ch= input.read())!=-1)
//            {
//                System.out.println((char)ch);
//            }
            Scanner scanner=new Scanner(input);
            while(scanner.hasNextLine())
            {
                String line=scanner.nextLine();
                System.out.println(line);
            }

        }
        catch(IOException ex)
        {
            System.err.println(ex);
        }
    }
}
