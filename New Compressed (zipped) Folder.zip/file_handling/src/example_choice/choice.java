package example_choice;

import java.io.*;
import java.util.Scanner;

public class choice {
    public void Reading( ) {
        try {
            Reader input = new FileReader("data.txt");//for charstream
            Scanner scanner = new Scanner(input);
            while (scanner.hasNextLine()) {
                String line = scanner.nextLine();
                System.out.println(line);
            }

        } catch (IOException ex) {
            System.err.println(ex);
        }
    }
    public void Writing( )
    {
        Writer output = null;
        try {
            output = new FileWriter("output.txt", true);
            String lines = """
                        im writing on these file with my updated ans
                        """;
            output.write(lines);
        } catch (IOException ex) {
            System.err.println(ex);
        } finally {
            try {
                output.close();
            } catch (IOException e) {
                throw new RuntimeException(e);
            }
        }
    }
    public static void main(String[] args) {

        System.out.println("enter your choice");
        Scanner scanner=new Scanner(System.in);
        int c=scanner.nextInt();
        choice p1=new choice();

        switch(c)
        {
            case 1:
                p1.Writing();
            break;
            case 2:
                p1.Reading();
                break;
            default:
                System.out.println("wrong choice");
        }
    }

}
