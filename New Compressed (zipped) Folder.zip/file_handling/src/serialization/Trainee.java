package serialization;

public class Trainee {
    private int id;

}
