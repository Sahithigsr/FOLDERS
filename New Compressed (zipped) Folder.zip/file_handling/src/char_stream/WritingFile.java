package char_stream;

import java.io.*;

public class WritingFile {
    public static void main(String[] args) {
        Writer output = null;
        try
        {
            output=new FileWriter("output.txt",true);
            String lines= """
                     im writing on these file with cs
                     """;
            output.write(lines);
        }
        catch(IOException ex)
        {
            System.err.println(ex);
        }
        finally
        {
            try {
                output.close();
            } catch (IOException e) {
                throw new RuntimeException(e);
            }
        }
    }
}
