package char_stream;

import java.io.*;
import java.util.Scanner;

public class ReadingFile {
    public static void main(String[] args) {
        try
        {
            Reader input=new FileReader("data.txt");//for charstream
            Scanner scanner=new Scanner(input);
            while(scanner.hasNextLine())
            {
                String line=scanner.nextLine();
                System.out.println(line);
            }

        }
        catch(IOException ex)
        {
            System.err.println(ex);
        }
    }
}
