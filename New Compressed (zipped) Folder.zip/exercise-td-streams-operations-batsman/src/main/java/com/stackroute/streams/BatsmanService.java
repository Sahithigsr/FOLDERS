package com.stackroute.streams;

import java.util.List;
import java.util.Map;
import java.util.Optional;

public class BatsmanService {
//    Batsman Batsman=new Batsman();
//    Country Country=new Country();


    public Optional<Batsman> getBatsman(List<Batsman> batsmanList,String searchName, String searchCountryCode) {
        if(batsmanList==null || batsmanList.isEmpty()|| searchName==null ||searchCountryCode==null)
        {
            return Optional.empty();
        }

        return Optional.of(batsmanList.stream()
                .filter(i -> i.getName().equals(searchName) && i.getCountry().getCountryCode().equals(searchCountryCode)).findFirst()
        ).get();


    }
    public String getBatsmanNamesForCountry(List<Batsman> batsmanList,String in)
    {
        return null;

    }


    public Map<String, Integer> getPlayerNameWithTotalRuns(List<Batsman> batsmanList) {
        return null;
    }

    public Integer getHighestRunsScoredByBatsman(List<Batsman> batsmanList, String australia) {
        return 0;
    }

    public Optional<List<String>> getPlayerNamesByCountry(List<Batsman> batsmanList, String india) {
        return Optional.empty();
    }
}
