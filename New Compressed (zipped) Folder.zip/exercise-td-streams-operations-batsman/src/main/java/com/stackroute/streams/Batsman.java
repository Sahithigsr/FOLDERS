package com.stackroute.streams;

public class Batsman {


        String name;
        int MatchesPlayed;
        int TotalRuns;
    int HighestScore;
    Country Country;

    public Batsman(String name, int matchesPlayed, int totalRuns, int highestScore, com.stackroute.streams.Country country) {
        this.name = name;
        MatchesPlayed = matchesPlayed;
        TotalRuns = totalRuns;
        HighestScore = highestScore;
        Country= new Country();
        Country.setName(country.getName());
        Country.setCountryCode(country.getCountryCode());
    }

    public Batsman() {

    }

    public com.stackroute.streams.Country getCountry() {
        return Country;
    }

    public void setCountry(com.stackroute.streams.Country country) {
        Country = country;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public int getMatchesPlayed() {
        return MatchesPlayed;
    }

    public void setMatchesPlayed(int matchesPlayed) {
        MatchesPlayed = matchesPlayed;
    }

    public int getTotalRuns() {
        return TotalRuns;
    }

    public void setTotalRuns(int totalRuns) {
        TotalRuns = totalRuns;
    }

    public int getHighestScore() {
        return HighestScore;
    }

    public void setHighestScore(int highestScore) {
        HighestScore = highestScore;
    }


}
