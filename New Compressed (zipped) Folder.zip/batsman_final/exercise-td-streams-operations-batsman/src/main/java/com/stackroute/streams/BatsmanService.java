package com.stackroute.streams;

import java.util.List;
import java.util.Map;
import java.util.Optional;

public class BatsmanService {
    public Optional<Batsman> getBatsman(List<Batsman> batsmanList, String virat, String in) {

        if(batsmanList.isEmpty() || virat==null || in==null|| batsmanList==null)
        {
            return Optional.empty();
        }
        return Optional.of(batsmanList.stream().filter(i->i.getName().equalsIgnoreCase(virat) && i.getCountry().getCountryCode().equalsIgnoreCase(in)).findFirst()).get();

    }

    public String getBatsmanNamesForCountry(List<Batsman> batsmanList, String in) {

       return "["+batsmanList.stream().filter(i->i.getCountry().getCountryCode().equalsIgnoreCase(in)).toString()+"]";

    }

    public Map<String, Integer> getPlayerNameWithTotalRuns(List<Batsman> batsmanList) {
        return null;
    }

    public Integer getHighestRunsScoredByBatsman(List<Batsman> batsmanList, String australia) {
        return batsmanList.stream().filter(i->i.getCountry().getName().equalsIgnoreCase(australia)).map(i->i.getTotalRuns()).sorted((i,j)->(i-j)).findFirst().get();

    }

    public Optional<List<String>> getPlayerNamesByCountry(List<Batsman> batsmanList, String india) {
        if(batsmanList.isEmpty()||batsmanList==null ||india==null)
        {
            return Optional.empty();
        }
        return null;
    }
}
