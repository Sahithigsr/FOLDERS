package com.example.demo.service;

import com.example.demo.MODEL.userModel;
import com.example.demo.dto.JwtToken;
import com.example.demo.dto.UserCredientials;
import com.example.demo.repository.UserRepo;
import com.example.demo.util.JwtUtil;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.core.userdetails.UsernameNotFoundException;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Service;

@Service
public class AuthService {

    //generate jwt  so create jwtutil

    @Autowired
    private UserRepo userRepo;

    @Autowired
    private PasswordEncoder passwordEncoder;

    @Autowired
    private JwtUtil jwtUtil;

    public JwtToken generateJwt(UserCredientials userCredientials)
    {
        userModel userModel=userRepo.findByUsername(userCredientials.getUsername()).orElseThrow(()->new UsernameNotFoundException("User name doesnt exists"));

        if(!passwordEncoder.matches(userCredientials.getPassword(),userModel.getPassword()))
        {
            throw new RuntimeException("invalid crediantials");

        }
        String jwt= jwtUtil.generateToken(userModel.getUsername());
        return new JwtToken(jwt);

    }
}
