package com.example.demo.service;


import com.example.demo.MODEL.userModel;
import com.example.demo.repository.UserRepo;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.security.core.userdetails.UserDetailsService;
import org.springframework.security.core.userdetails.UsernameNotFoundException;
import org.springframework.stereotype.Service;

@Service
public class UserDetailsServiceIMpl implements UserDetailsService {

    @Autowired
    private UserRepo userRepo;

    @Override
    public UserDetails loadUserByUsername(String username) throws UsernameNotFoundException {
        userModel userModel=userRepo.findByUsername(username).orElseThrow(()->new UsernameNotFoundException("User name doesnt exists"));
        return new UserDetailsImpl(userModel);

    }
}
