package com.example.demo.api;


import com.example.demo.dto.JwtToken;
import com.example.demo.dto.UserCredientials;
import com.example.demo.service.AuthService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
@RequestMapping("/api/public")
public class AuthController {

    @Autowired
    private AuthService authService;

    @PostMapping("/login")
    public JwtToken login(@RequestBody UserCredientials userCredientials)
    {

        return authService.generateJwt(userCredientials);
    }

}
