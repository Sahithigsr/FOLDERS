package com.example.demo.repository;

import com.example.demo.MODEL.userModel;
import org.springframework.data.jpa.repository.JpaRepository;

import java.util.Optional;

public interface UserRepo extends JpaRepository<userModel,Integer> {

    Optional<userModel>findByUsername(String username);
}
