package com.example.demo.api;

import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
public class PublicController {

    @GetMapping("/hello/secured")
    public String sayHelloAdmin()
    {
        return "hello admin";
    }

    @GetMapping("/hello/all")
    public String sayHelloAll()
    {
        return "hello all";
    }
}
