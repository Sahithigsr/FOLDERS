package com.example.demo.MODEL;

import lombok.Data;
import org.springframework.boot.autoconfigure.domain.EntityScan;

import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name = "demoUserModel")
@Data
public class userModel {

    @Id
    private int id;
    private String username;
    private String password;
    private String role;

}
