package com.example.service;

import com.example.dto.JwtToken;
import com.example.dto.UserCredentials;
import com.example.model.UserModel;
import com.example.repository.UserRepository;
import com.example.util.JwtUtil;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.core.userdetails.UsernameNotFoundException;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Service;

@Service
public class AuthenticationService {

    //1.take crediantials, check if user is present from repo(not from userdetailsserviceimpl it is for spring security),
//    2. check whether password is matching or not
//    3. if all fine generate token


    @Autowired
    private JwtUtil jwtUtil;

    @Autowired
    private UserRepository userRepository;

    @Autowired
    PasswordEncoder passwordEncoder;

    public JwtToken loginUser(UserCredentials userCredentials)
    {
        UserModel userModel=userRepository.findByUsername(userCredentials.username())
                .orElseThrow(()->new UsernameNotFoundException("user with name "+ userCredentials.username()+" not found"));

        if(!passwordEncoder.matches(userCredentials.password(),userModel.getPassword()))
        {
            throw  new RuntimeException("Invalid Credentials");
        }

        String jwt=jwtUtil.generateToken(userCredentials.username());
        return new JwtToken(jwt);

    }

}
