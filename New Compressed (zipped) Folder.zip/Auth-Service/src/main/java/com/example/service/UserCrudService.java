package com.example.service;

import com.example.model.UserModel;

public interface UserCrudService {
    public UserModel saveUser(UserModel userModel);
}
