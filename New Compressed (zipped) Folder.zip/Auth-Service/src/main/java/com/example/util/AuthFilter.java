package com.example.util;

import jakarta.servlet.FilterChain;
import jakarta.servlet.ServletException;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Configuration;
import org.springframework.security.authentication.UsernamePasswordAuthenticationToken;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.security.core.userdetails.UserDetailsService;
import org.springframework.security.web.authentication.WebAuthenticationDetailsSource;
import org.springframework.web.filter.OncePerRequestFilter;

import java.io.IOException;

@Configuration
@Slf4j
public class AuthFilter extends OncePerRequestFilter {

    //from token, generate username
    //chcek if that username is there in database

    @Autowired
    private JwtUtil jwtUtil;

    @Autowired
    private UserDetailsService userDetailsService;


    @Override
    protected void doFilterInternal(HttpServletRequest request, HttpServletResponse response, FilterChain filterChain) throws ServletException, IOException {

        String jwt=null;
        String header=null;
        String username=null;
        log.info("filter intercepted");
        header = request.getHeader("Authorization");
        if(header!=null && header.startsWith("Bearer"))
        {
            jwt=header.substring(7);
            log.info("Received jwt is :" + jwt);
            username = jwtUtil.getUsernameFromToken(jwt);
            log.info("username: " + username);
        }


        if(username!=null && SecurityContextHolder.getContext().getAuthentication() == null)
        {
            UserDetails userDetails= userDetailsService.loadUserByUsername(username);
            //for spring say dont do more filter,enough dont do overaction!
            if(jwtUtil.validateToken(jwt,userDetails))
            {
                UsernamePasswordAuthenticationToken authToken =  new UsernamePasswordAuthenticationToken(userDetails,null,userDetails.getAuthorities());
                authToken.setDetails(new WebAuthenticationDetailsSource().buildDetails(request));
                SecurityContextHolder.getContext().setAuthentication(authToken);
                filterChain.doFilter(request,response);

            }
        }





//        log.info("filter intercepted");
//        String header = request.getHeader("Authorization");
//        if (SecurityContextHolder.getContext().getAuthentication() != null) {
//            if (header == null || header.isBlank()) {
//                log.error("No Authorization header sent");
//                return;
//            }
//            String jwt = header.substring(7);
//            log.info("Received jwt is :" + jwt);
//            String username = jwtUtil.getUsernameFromToken(jwt);
//            log.info("username: " + username);
//
//            filterChain.doFilter(request, response);
//        }
        filterChain.doFilter(request, response);
    }
}
