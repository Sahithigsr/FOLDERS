package com.example.api;


import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
@RequestMapping("/app")
public class AppController {

    @GetMapping("/hello")
    public String sayHello()
    {
        return "Hello ALL";
    }

    @GetMapping("/hello/admin")
    public String sayHelloAdmin()
    {
        return "hello admin";
    }

    @GetMapping("/hello/user")
    public String sayHelloUser()
    {
        return "hello user";
    }




}
