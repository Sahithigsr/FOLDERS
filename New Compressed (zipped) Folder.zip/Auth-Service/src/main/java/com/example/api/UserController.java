package com.example.api;

import com.example.model.UserModel;
import com.example.service.UserCrudService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
@RequestMapping("/users")
public class UserController {

    @Autowired
    private UserCrudService userCrudService;

    @PostMapping
    public UserModel createUser(@RequestBody UserModel userModel)
    {
        return userCrudService.saveUser(userModel);

    }
}
