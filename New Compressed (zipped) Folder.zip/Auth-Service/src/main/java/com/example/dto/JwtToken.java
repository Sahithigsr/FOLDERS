package com.example.dto;

public record JwtToken(String jwt) {
}
