package com.example.dto;

public record UserCredentials(String username,String password) {
}
