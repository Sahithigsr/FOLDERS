public class Student {
    private  String branch;

    public Student(String branch){
        this.branch=branch;
    }

    public String getBranch() {
        return branch;
    }

    public void setBranch(String branch) {
        this.branch = branch;
    }
}
