public class Person {
    public static void main(String[] args) {
        int []arr = {2,3,0};

        try {
            int output = arr[0] / arr[8];
            System.out.println(output);
        }
        catch (Exception ex){
            System.err.println(ex);
        }
//        catch(ArrayIndexOutOfBoundsException ex)
//        {
//            System.err.println(ex);
//        }

    }
}
