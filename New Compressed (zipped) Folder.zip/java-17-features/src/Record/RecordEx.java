package Record;

import java.time.LocalDate;

public class RecordEx {
    public static void main(String[] args) {
        Trainee t1=new Trainee(1,"gsr", LocalDate.of(2024,8,15));
        System.out.println(t1);
        t1.name();
    }
}
