package Record;

import java.time.LocalDate;
//all setters getters constructors will not be required if u write record instead of class
public record Trainee (int id, String name, LocalDate dateJoined){
    public Trainee(int id)
    {
        this(id,null,null);
    }

}
