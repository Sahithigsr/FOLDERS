package sealed_classes;

public final class Developer extends Employee {
}
