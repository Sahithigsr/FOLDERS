package sealed_classes;

public sealed class Employee permits Manager,Developer{

}
