package sealed_classes;

public non-sealed class Manager extends Employee{
}
